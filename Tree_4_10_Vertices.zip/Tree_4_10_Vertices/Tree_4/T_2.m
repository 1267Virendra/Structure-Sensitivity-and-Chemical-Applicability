clc
clear all
close all
path(path,'C:\Users\User\Dropbox\Ph.D\2_Programming\1_MatLab\8_NI_QSPR\Tree_4_10_Vertices')
Data1=xlsread('Tree_4.xlsx',1);
Data2=xlsread('Tree_4.xlsx',2);
A=Data1(2,:);
B=Data2(1:23,5);
C=zeros(23,1);
D=zeros(1,23);
E=zeros(1,23);

for i=1:23
    ss=0;
    for j=1:1
        s=abs((B(i,j)-A(i))./A(i));
        ss=ss+s;
        C(i,j)=s;
    end
    sm=ss./1;
   D(i)=sm;
    %fprintf('%f \n',sm);
end
%disp(C)
disp(D)
for k=1:23
    M=max(C(k,:));
    E(k)=M;
    %fprintf('%f\n',M);

end
disp(E)