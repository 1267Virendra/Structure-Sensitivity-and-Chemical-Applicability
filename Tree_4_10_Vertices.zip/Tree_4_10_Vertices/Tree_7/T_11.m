clc
clear all
close all
path(path,'C:\Users\User\Dropbox\Student_Virendra\10_Experimental_Results')
Data1=xlsread('Tree_7.xlsx',2);
Data2=xlsread('Tree_7.xlsx',3);
A=Data1(11,:);
B=Data2(1:23,76:81);
C=zeros(23,6);
D=zeros(1,23);
E=zeros(1,23);

for i=1:23
    ss=0;
    for j=1:6
        s=abs((B(i,j)-A(i))./A(i));
        ss=ss+s;
        C(i,j)=s;
    end
    sm=ss./6;
   D(i)=sm;
    %fprintf('%f \n',sm);
end
%disp(C)
disp(D)
for k=1:23
    M=max(C(k,:));
    E(k)=M;
    %fprintf('%f\n',M);

end
disp(E)