clc
clear all
close all
path(path,'C:\Users\User\Dropbox\Student_Virendra\9_SS-Abr_Nirmala_indices')
Data1=xlsread('Tree_9.xlsx',1)
Data2=xlsread('Tree_9.xlsx',2)
A=Data1(29,:)
B=Data2(1:24,608:627)
C=zeros(24,20);
D=zeros(1,24);
E=zeros(1,24);

for i=1:24
    ss=0;
    for j=1:20
        s=abs((B(i,j)-A(i))./A(i));
        ss=ss+s;
        C(i,j)=s;
    end
    sm=ss./20;
   D(i)=sm;
    %fprintf('%f \n',sm);
end
%disp(C)
disp(D)
for k=1:24
    M=max(C(k,:));
    E(k)=M;
    %fprintf('%f\n',M);

end
disp(E)