# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 14:54:55 2022

@author: User
"""

import networkx as nx 





T17=nx.Graph()
edgelist17=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(4,9)]
T17.add_edges_from(edgelist17)
k17=nx.graph_edit_distance(T17, T17)
print('Tree T17 and T17 are at GED=',k17)


T18=nx.Graph()
edgelist18=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(5,9)]
T18.add_edges_from(edgelist18)
k18=nx.graph_edit_distance(T17, T18)
print('Tree T17 and T18 are at GED=',k18)


T19=nx.Graph()
edgelist19=[(1,2),(2,3),(3,4),(4,5),(5,6),(4,7),(4,8),(5,9)]
T19.add_edges_from(edgelist19)
k19=nx.graph_edit_distance(T17, T19)
print('Tree T17 and T19 are at GED=',k19)



T20=nx.Graph()
edgelisT20=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(4,9)]
T20.add_edges_from(edgelisT20)
k20=nx.graph_edit_distance(T17, T20)
print('Tree T17 and T20 are at GED=',k20)


T21=nx.Graph()
edgelisT21=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(4,8),(5,9)]
T21.add_edges_from(edgelisT21)
k21=nx.graph_edit_distance(T17, T21)
print('Tree T17 and T21 are at GED=',k21)


T22=nx.Graph()
edgelisT22=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(5,9)]
T22.add_edges_from(edgelisT22)
k22=nx.graph_edit_distance(T17, T22)
print('Tree T17 and T22 are at GED=',k22)


T23=nx.Graph()
edgelisT23=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(4,9)]
T23.add_edges_from(edgelisT23)
k23=nx.graph_edit_distance(T17, T23)
print('Tree T17 and T23 are at GED=',k23)


T24=nx.Graph()
edgelisT24=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(8,9)]
T24.add_edges_from(edgelisT24)
k24=nx.graph_edit_distance(T17, T24)
print('Tree T17 and T24 are at GED=',k24)

T25=nx.Graph()
edgelisT25=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(4,8),(8,9)]
T25.add_edges_from(edgelisT25)
k25=nx.graph_edit_distance(T17, T25)
print('Tree T17 and T25 are at GED=',k25)

T26=nx.Graph()
edgelisT26=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(8,9)]
T26.add_edges_from(edgelisT26)
k26=nx.graph_edit_distance(T17, T26)
print('Tree T17 and T26 are at GED=',k26)

T27=nx.Graph()
edgelisT27=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(4,8),(8,9)]
T27.add_edges_from(edgelisT27)
k27=nx.graph_edit_distance(T17, T27)
print('Tree T17 and T27 are at GED=',k27)

T28=nx.Graph()
edgelisT28=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(3,8),(3,9)]
T28.add_edges_from(edgelisT28)
k28=nx.graph_edit_distance(T17, T28)
print('Tree T17 and T28 are at GED=',k28)

T29=nx.Graph()
edgelisT29=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(3,8),(4,9)]
T29.add_edges_from(edgelisT29)
k29=nx.graph_edit_distance(T17, T29)
print('Tree T17 and T29 are at GED=',k29)

T30=nx.Graph()
edgelist30=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(4,8),(4,9)]
T30.add_edges_from(edgelist30)
k30=nx.graph_edit_distance(T17, T30)
print('Tree T17 and T30 are at GED=',k30)

T31=nx.Graph()
edgelist31=[(1,2),(2,3),(3,4),(4,5),(2,6),(3,7),(3,8),(4,9)]
T31.add_edges_from(edgelist31)
k31=nx.graph_edit_distance(T17, T31)
print('Tree T17 and T31 are at GED=',k31)

T32=nx.Graph()
edgelist32=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(3,8),(8,9)]
T32.add_edges_from(edgelist32)
k32=nx.graph_edit_distance(T17, T32)
print('Tree T17 and T32 are at GED=',k32)

T33=nx.Graph()
edgelist33=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(7,8),(7,9)]
T33.add_edges_from(edgelist33)
k33=nx.graph_edit_distance(T17, T33)
print('Tree T17 and T33 are at GED=',k33)

T34=nx.Graph()
edgelist34=[(1,2),(2,3),(3,4),(4,5),(2,6),(3,7),(7,8),(4,9)]
T34.add_edges_from(edgelist34)
k34=nx.graph_edit_distance(T17, T34)
print('Tree T17 and T34 are at GED=',k34)

T35=nx.Graph()
edgelist35=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(6,8),(7,9)]
T35.add_edges_from(edgelist35)
k35=nx.graph_edit_distance(T17, T35)
print('Tree T17 and T35 are at GED=',k35)

T36=nx.Graph()
edgelist36=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9)]
T36.add_edges_from(edgelist36)
k36=nx.graph_edit_distance(T17, T36)
print('Tree T17 and T36 are at GED=',k36)

T37=nx.Graph()
edgelist37=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9)]
T37.add_edges_from(edgelist37)
k37=nx.graph_edit_distance(T17, T37)
print('Tree T17 and T37 are at GED=',k37)

T38=nx.Graph()
edgelist38=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(2,8),(2,9)]
T38.add_edges_from(edgelist38)
k38=nx.graph_edit_distance(T17, T38)
print('Tree T17 and T38 are at GED=',k38)

T39=nx.Graph()
edgelist39=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(3,8),(3,9)]
T39.add_edges_from(edgelist39)
k39=nx.graph_edit_distance(T17, T39)
print('Tree T17 and T39 are at GED=',k39)

T40=nx.Graph()
edgelisT40=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(2,8),(3,9)]
T40.add_edges_from(edgelisT40)
k40=nx.graph_edit_distance(T17, T40)
print('Tree T17 and T40 are at GED=',k40)

T41=nx.Graph()
edgelisT41=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(2,8),(4,9)]
T41.add_edges_from(edgelisT41)
k41=nx.graph_edit_distance(T17, T41)
print('Tree T17 and T41 are at GED=',k41)

T42=nx.Graph()
edgelisT42=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(3,8),(4,9)]
T42.add_edges_from(edgelisT42)
k42=nx.graph_edit_distance(T17, T42)
print('Tree T17 and T42 are at GED=',k42)

T43=nx.Graph()
edgelisT43=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(3,8),(8,9)]
T43.add_edges_from(edgelisT43)
k43=nx.graph_edit_distance(T17, T43)
print('Tree T17 and T43 are at GED=',k43)

T44=nx.Graph()
edgelisT44=[(1,2),(2,3),(3,4),(2,5),(2,6),(2,7),(2,8),(2,9)]
T44.add_edges_from(edgelisT44)
k44=nx.graph_edit_distance(T17, T44)
print('Tree T17 and T44 are at GED=',k44)

T45=nx.Graph()
edgelisT45=[(1,2),(2,3),(3,4),(2,5),(2,6),(2,7),(2,8),(3,9)]
T45.add_edges_from(edgelisT45)
k45=nx.graph_edit_distance(T17, T45)
print('Tree T17 and T45 are at GED=',k45)

T46=nx.Graph()
edgelisT46=[(1,2),(2,3),(3,4),(2,5),(2,6),(2,7),(3,8),(3,9)]
T46.add_edges_from(edgelisT46)
k46=nx.graph_edit_distance(T17, T46)
print('Tree T17 and T46 are at GED=',k46)

T47=nx.Graph()
edgelisT47=[(1,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,9)]
T47.add_edges_from(edgelisT47)
k47=nx.graph_edit_distance(T17, T47)
print('Tree T17 and T47 are at GED=',k47)
