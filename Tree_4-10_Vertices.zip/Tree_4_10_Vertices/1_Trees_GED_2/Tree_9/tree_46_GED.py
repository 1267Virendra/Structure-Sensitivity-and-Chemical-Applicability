# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 14:54:55 2022

@author: User
"""

import networkx as nx 


T46=nx.Graph()
edgelisT46=[(1,2),(2,3),(3,4),(2,5),(2,6),(2,7),(3,8),(3,9)]
T46.add_edges_from(edgelisT46)
k46=nx.graph_edit_distance(T46, T46)
print('Tree T46 and T46 are at GED=',k46)

T47=nx.Graph()
edgelisT47=[(1,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,9)]
T47.add_edges_from(edgelisT47)
k47=nx.graph_edit_distance(T46, T47)
print('Tree T46 and T47 are at GED=',k47)
