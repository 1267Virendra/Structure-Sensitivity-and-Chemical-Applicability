# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 14:54:55 2022

@author: User
"""

import networkx as nx 




T43=nx.Graph()
edgelisT43=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(3,8),(8,9)]
T43.add_edges_from(edgelisT43)
k43=nx.graph_edit_distance(T43, T43)
print('Tree T43 and T43 are at GED=',k43)

T44=nx.Graph()
edgelisT44=[(1,2),(2,3),(3,4),(2,5),(2,6),(2,7),(2,8),(2,9)]
T44.add_edges_from(edgelisT44)
k44=nx.graph_edit_distance(T43, T44)
print('Tree T43 and T44 are at GED=',k44)

T45=nx.Graph()
edgelisT45=[(1,2),(2,3),(3,4),(2,5),(2,6),(2,7),(2,8),(3,9)]
T45.add_edges_from(edgelisT45)
k45=nx.graph_edit_distance(T43, T45)
print('Tree T43 and T45 are at GED=',k45)

T46=nx.Graph()
edgelisT46=[(1,2),(2,3),(3,4),(2,5),(2,6),(2,7),(3,8),(3,9)]
T46.add_edges_from(edgelisT46)
k46=nx.graph_edit_distance(T43, T46)
print('Tree T43 and T46 are at GED=',k46)

T47=nx.Graph()
edgelisT47=[(1,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8),(2,9)]
T47.add_edges_from(edgelisT47)
k47=nx.graph_edit_distance(T43, T47)
print('Tree T43 and T47 are at GED=',k47)
