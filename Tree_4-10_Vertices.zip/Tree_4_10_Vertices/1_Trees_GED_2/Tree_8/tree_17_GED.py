

# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 14:54:55 2022

@author: User
"""

import networkx as nx 

T17=nx.Graph()
edgelist17=[(1,2),(2,3),(3,4),(4,5),(2,6),(4,7),(4,8)]
T17.add_edges_from(edgelist17)
k17=nx.graph_edit_distance(T17, T17)
print('Tree T17 and T17 are at GED=',k17)


T16=nx.Graph()
edgelist16=[(1,2),(2,3),(3,4),(4,5),(3,6),(4,7),(4,8)]
T16.add_edges_from(edgelist16)
k16=nx.graph_edit_distance(T17, T16)
print('Tree T17 and T16 are at GED=',k16)

T15=nx.Graph()
edgelist15=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(4,8)]
T15.add_edges_from(edgelist15)
k15=nx.graph_edit_distance(T17, T15)
print('Tree T17 and T15 are at GED=',k15)


T14=nx.Graph()
edgelist14=[(1,2),(2,3),(3,4),(4,5),(5,6),(5,7),(5,8)]
T14.add_edges_from(edgelist14)
k14=nx.graph_edit_distance(T17, T14)
print('Tree T17 and T14 are at GED=',k14)

T13=nx.Graph()
edgelist13=[(1,2),(2,3),(3,4),(4,5),(5,6),(4,7),(4,8)]
T13.add_edges_from(edgelist13)
k13=nx.graph_edit_distance(T17, T13)
print('Tree T17 and T13 are at GED=',k13)


T12=nx.Graph()
edgelist12=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(5,8)]
T12.add_edges_from(edgelist12)
k12=nx.graph_edit_distance(T17, T12)
print('Tree T17 and T12 are at GED=',k12)




T11=nx.Graph()
edgelist11=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(5,8)]
T11.add_edges_from(edgelist11)
k11=nx.graph_edit_distance(T17, T11)
print('Tree T17 and T11 are at GED=',k11)

T10=nx.Graph()
edgelist10=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(6,8)]
T10.add_edges_from(edgelist10)
k10=nx.graph_edit_distance(T17, T10)
print('Tree T17 and T10 are at GED=',k10)




T9=nx.Graph()
edgelist9=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8)]
T9.add_edges_from(edgelist9)
k9=nx.graph_edit_distance(T17, T9)
print('Tree T17 and T9 are at GED=',k9)




T8=nx.Graph()
edgelist8=[(1,2),(2,3),(3,4),(4,5),(4,6),(6,7),(6,8)]
T8.add_edges_from(edgelist8)
k8=nx.graph_edit_distance(T17, T8)
print('Tree T17 and T8 are at GED=',k8)

T7=nx.Graph()
edgelist7=[(1,2),(2,3),(3,4),(4,5),(2,6),(3,7),(4,8)]
T7.add_edges_from(edgelist7)
k7=nx.graph_edit_distance(T17, T7)
print('Tree T17 and T7 are at GED=',k7)


T6=nx.Graph()
edgelist6=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(7,8)]
T6.add_edges_from(edgelist6)
k6=nx.graph_edit_distance(T17, T6)
print('Tree T17 and T6 are at GED=',k6)

T5=nx.Graph()
edgelist5=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(4,8)]
T5.add_edges_from(edgelist5)
k5=nx.graph_edit_distance(T17, T5)
print('Tree T17 and T5 are at GED=',k5)


T4=nx.Graph()
edgelist4=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(5,8)]
T4.add_edges_from(edgelist4)
k4=nx.graph_edit_distance(T17, T4)
print('Tree T17 and T4 are at GED=',k4)

T3=nx.Graph()
edgelist3=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(7,8)]
T3.add_edges_from(edgelist3)
k3=nx.graph_edit_distance(T17, T3)
print('Tree T17 and T3 are at GED=',k3)

T2=nx.Graph()
edgelist2=[(1,2),(2,3),(3,4),(4,5),(3,6),(6,7),(6,8)]
T2.add_edges_from(edgelist2)
k2=nx.graph_edit_distance(T17, T2)
print('Tree T17 and T2 are at GED=',k2)

T1=nx.Graph()
edgelist1=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8)]
T1.add_edges_from(edgelist1)
k1=nx.graph_edit_distance(T17, T1)
print('Tree T17 and T1 are at GED=',k1)



























T18=nx.Graph()
edgelist18=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(3,8)]
T18.add_edges_from(edgelist18)
k18=nx.graph_edit_distance(T17, T18)
print('Tree T17 and T18 are at GED=',k18)


T19=nx.Graph()
edgelist19=[(1,2),(2,3),(3,4),(2,5),(2,6),(3,7),(3,8)]
T19.add_edges_from(edgelist19)
k19=nx.graph_edit_distance(T17, T19)
print('Tree T17 and T19 are at GED=',k19)



T20=nx.Graph()
edgelist20=[(1,2),(2,3),(3,4),(2,5),(3,6),(3,7),(3,8)]
T20.add_edges_from(edgelist20)
k20=nx.graph_edit_distance(T17, T20)
print('Tree T17 and T20 are at GED=',k20)


T21=nx.Graph()
edgelist21=[(1,2),(2,3),(3,4),(4,5),(4,6),(4,7),(4,8)]
T21.add_edges_from(edgelist21)
k21=nx.graph_edit_distance(T17, T21)
print('Tree T17 and T21 are at GED=',k21)


T22=nx.Graph()
edgelist22=[(1,2),(2,3),(3,4),(3,5),(3,6),(3,7),(3,8)]
T22.add_edges_from(edgelist22)
k22=nx.graph_edit_distance(T17, T22)
print('Tree T17 and T22 are at GED=',k22)


T23=nx.Graph()
edgelist23=[(1,2),(2,3),(2,4),(2,5),(2,6),(2,7),(2,8)]
T23.add_edges_from(edgelist23)
k23=nx.graph_edit_distance(T17, T23)
print('Tree T17 and T23 are at GED=',k23)
