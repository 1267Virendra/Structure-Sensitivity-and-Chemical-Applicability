# -*- coding: utf-8 -*-
"""
Created on Thu Sep  1 10:42:58 2022

@author: User
"""




import networkx as nx 


T11=nx.Graph()
edgelist11=[(1,2),(2,3),(3,4),(2,5),(2,6),(3,7)]
T11.add_edges_from(edgelist11)

k11=nx.graph_edit_distance(T11, T11)
print('Tree T11 and T11 are at GED=',k11)






T10=nx.Graph()
edgelist10=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7)]
T10.add_edges_from(edgelist10)

k10=nx.graph_edit_distance(T11, T10)
print('Tree T11 and T10 are at GED=',k10)





T9=nx.Graph()
edgelist9=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7)]
T9.add_edges_from(edgelist9)

k9=nx.graph_edit_distance(T11, T9)
print('Tree T11 and T9 are at GED=',k9)







T8=nx.Graph()
edgelist8=[(1,2),(2,3),(3,4),(4,5),(2,6),(3,7)]
T8.add_edges_from(edgelist8)

k8=nx.graph_edit_distance(T11, T8)
print('Tree T11 and T8 are at GED=',k8)







T7=nx.Graph()
edgelist7=[(1,2),(2,3),(3,4),(4,5),(2,6),(4,7)]
T7.add_edges_from(edgelist7)

k7=nx.graph_edit_distance(T11, T7)
print('Tree T11 and T7 are at GED=',k7)





T6=nx.Graph()
edgelist6=[(1,2),(2,3),(3,4),(4,5),(3,6),(6,7)]
T6.add_edges_from(edgelist6)

k6=nx.graph_edit_distance(T11, T6)
print('Tree T11 and T6 are at GED=',k6)

T5=nx.Graph()
edgelist5=[(1,2),(2,3),(3,4),(4,5),(5,6),(4,7)]
T5.add_edges_from(edgelist5)

k5=nx.graph_edit_distance(T11, T5)
print('Tree T11 and T5 are at GED=',k5)


T4=nx.Graph()
edgelist4=[(1,2),(2,3),(3,4),(4,5),(5,6),(5,7)]
T4.add_edges_from(edgelist4)

k4=nx.graph_edit_distance(T11, T4)
print('Tree T11 and T4 are at GED=',k4)




T1=nx.Graph()
edgelist1=[(1,7),(2,7),(3,7),(4,7),(5,7),(6,7)]
T1.add_edges_from(edgelist1)
k1=nx.graph_edit_distance(T11, T1)
print('Tree T11 and T1 are at GED=',k1)


T2=nx.Graph()
edgelist2=[(1,2),(2,3),(3,4),(5,2),(6,2),(7,2)]
T2.add_edges_from(edgelist2)

k2=nx.graph_edit_distance(T11, T2)
print('Tree T11 and T2 are at GED=',k2)


T3=nx.Graph()
edgelist3=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7)]
T3.add_edges_from(edgelist3)

k3=nx.graph_edit_distance(T11, T3)
print('Tree T11 and T3 are at GED=',k3)















