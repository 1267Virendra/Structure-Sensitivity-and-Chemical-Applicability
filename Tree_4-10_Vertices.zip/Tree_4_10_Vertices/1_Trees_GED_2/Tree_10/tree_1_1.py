# -*- coding: utf-8 -*-
"""
Created on Sun Sep 18 17:45:21 2022

@author: User
"""

import networkx as nx 

T1=nx.Graph()
edgelist1=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(9,10)]
T1.add_edges_from(edgelist1)
k1=nx.graph_edit_distance(T1, T1)
print('Tree T1 and T1 are at GED=',k1)





T104=nx.Graph()
edgelist104=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(2,9),(2,10)]
T104.add_edges_from(edgelist104)
k104=nx.graph_edit_distance(T1, T104)
print('Tree T1 and T104 are at GED=',k104)


T105=nx.Graph()
edgelist105=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(3,9),(3,10)]
T105.add_edges_from(edgelist105)
k105=nx.graph_edit_distance(T1, T105)
print('Tree T1 and T105 are at GED=',k105)


T106=nx.Graph()
edgelist106=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(4,9),(4,10)]
T106.add_edges_from(edgelist106)
k106=nx.graph_edit_distance(T1, T106)
print('Tree T1 and T106 are at GED=',k106)


T95=nx.Graph()
edgelist95=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(2,10)]
T95.add_edges_from(edgelist95)
k95=nx.graph_edit_distance(T1, T95)
print('Tree T1 and T95 are at GED=',k95)


T96=nx.Graph()
edgelist96=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(3,10)]
T96.add_edges_from(edgelist96)
k96=nx.graph_edit_distance(T1, T96)
print('Tree T1 and T96 are at GED=',k96)


T97=nx.Graph()
edgelist97=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(3,10)]
T97.add_edges_from(edgelist97)
k97=nx.graph_edit_distance(T1, T97)
print('Tree T1 and T97 are at GED=',k97)


T98=nx.Graph()
edgelist98=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(4,10)]
T98.add_edges_from(edgelist98)
k98=nx.graph_edit_distance(T1, T98)
print('Tree T1 and T98 are at GED=',k98)


T99=nx.Graph()
edgelist99=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(5,10)]
T99.add_edges_from(edgelist99)
k99=nx.graph_edit_distance(T1, T99)
print('Tree T1 and T99 are at GED=',k99)

T100=nx.Graph()
edgelist100=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(4,10)]
T100.add_edges_from(edgelist100)
k100=nx.graph_edit_distance(T1, T100)
print('Tree T1 and T100 are at GED=',k100)


T101=nx.Graph()
edgelist101=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(5,10)]
T101.add_edges_from(edgelist101)
k101=nx.graph_edit_distance(T1, T101)
print('Tree T1 and T101 are at GED=',k101)


T102=nx.Graph()
edgelist102=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(3,9),(3,10)]
T102.add_edges_from(edgelist102)
k102=nx.graph_edit_distance(T1, T102)
print('Tree T1 and T102 are at GED=',k102)


T103=nx.Graph()
edgelist103=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(9,10)]
T103.add_edges_from(edgelist103)
k103=nx.graph_edit_distance(T1, T103)
print('Tree T1 and T103 are at GED=',k103)




