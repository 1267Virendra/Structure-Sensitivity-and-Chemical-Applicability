import networkx as nx 

T21=nx.Graph()
edgelist21=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(8,9),(8,10)]
T21.add_edges_from(edgelist21)
k21=nx.graph_edit_distance(T21, T21)
print('Tree T21 and T21 are at GED=',k21)


T8=nx.Graph()
edgelisT8=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(2,9),(2,10)]
T8.add_edges_from(edgelisT8)
k8=nx.graph_edit_distance(T21, T8)
print('Tree T21 and T8 are at GED=',k8)


T7=nx.Graph()
edgelist7=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(4,9),(9,10)]
T7.add_edges_from(edgelist7)
k7=nx.graph_edit_distance(T21, T7)
print('Tree T21 and T7 are at GED=',k7)

T6=nx.Graph()
edgelist6=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(3,9),(9,10)]
T6.add_edges_from(edgelist6)
k6=nx.graph_edit_distance(T21, T6)
print('Tree T21 and T6 are at GED=',k6)

T5=nx.Graph()
edgelist5=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(5,10)]
T5.add_edges_from(edgelist5)
k5=nx.graph_edit_distance(T21, T5)
print('Tree T21 and T5 are at GED=',k5)


T4=nx.Graph()
edgelist4=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(4,10)]
T4.add_edges_from(edgelist4)
k4=nx.graph_edit_distance(T21, T4)
print('Tree T21 and T4 are at GED=',k4)


T3=nx.Graph()
edgelist3=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(3,10)]
T3.add_edges_from(edgelist3)
k3=nx.graph_edit_distance(T21, T3)
print('Tree T21 and T3 are at GED=',k3)

T2=nx.Graph()
edgelist2=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(2,10)]
T2.add_edges_from(edgelist2)
k2=nx.graph_edit_distance(T21, T2)
print('Tree T21 and T2 are at GED=',k2)




T1=nx.Graph()
edgelist1=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(8,9),(9,10)]
T1.add_edges_from(edgelist1)
k1=nx.graph_edit_distance(T21, T1)
print('Tree T21 and T1 are at GED=',k1)








T9=nx.Graph()
edgelist9=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(6,9),(7,10)]
T9.add_edges_from(edgelist9)
k9=nx.graph_edit_distance(T21, T9)
print('Tree T21 and T9 are at GED=',k9)

T10=nx.Graph()
edgelist10=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(5,9),(7,10)]
T10.add_edges_from(edgelist10)
k10=nx.graph_edit_distance(T21, T10)
print('Tree T21 and T10 are at GED=',k10)

T11=nx.Graph()
edgelist11=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(4,9),(7,10)]
T11.add_edges_from(edgelist11)
k11=nx.graph_edit_distance(T21, T11)
print('Tree T21 and T11 are at GED=',k11)


T12=nx.Graph()
edgelist12=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(3,9),(7,10)]
T12.add_edges_from(edgelist12)
k12=nx.graph_edit_distance(T21, T12)
print('Tree T21 and T12 are at GED=',k12)


T13=nx.Graph()
edgelist13=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(2,9),(7,10)]
T13.add_edges_from(edgelist13)
k13=nx.graph_edit_distance(T21, T13)
print('Tree T21 and T13 are at GED=',k13)

T14=nx.Graph()
edgelist14=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(3,9),(3,10)]
T14.add_edges_from(edgelist14)
k14=nx.graph_edit_distance(T21, T14)
print('Tree T21 and T14 are at GED=',k14)


T15=nx.Graph()
edgelist15=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(5,9),(6,10)]
T15.add_edges_from(edgelist15)
k15=nx.graph_edit_distance(T21, T15)
print('Tree T21 and T15 are at GED=',k15)


T16=nx.Graph()
edgelist16=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(4,9),(6,10)]
T16.add_edges_from(edgelist16)
k16=nx.graph_edit_distance(T21, T16)
print('Tree T21 and T16 are at GED=',k16)



T17=nx.Graph()
edgelist17=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(3,9),(6,10)]
T17.add_edges_from(edgelist17)
k17=nx.graph_edit_distance(T21, T17)
print('Tree T21 and T17 are at GED=',k17)


T18=nx.Graph()
edgelist18=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(4,9),(4,10)]
T18.add_edges_from(edgelist18)
k18=nx.graph_edit_distance(T21, T18)
print('Tree T21 and T18 are at GED=',k18)


T19=nx.Graph()
edgelist19=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(7,8),(4,9),(5,10)]
T19.add_edges_from(edgelist19)
k19=nx.graph_edit_distance(T21, T19)
print('Tree T21 and T19 are at GED=',k19)



T20=nx.Graph()
edgelist20=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(8,9),(9,10)]
T20.add_edges_from(edgelist20)
k20=nx.graph_edit_distance(T21, T20)
print('Tree T21 and T20 are at GED=',k20)





T22=nx.Graph()
edgelist22=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(5,8),(8,9),(6,10)]
T22.add_edges_from(edgelist22)
k22=nx.graph_edit_distance(T21, T22)
print('Tree T21 and T22 are at GED=',k22)


T23=nx.Graph()
edgelist23=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(8,9),(3,10)]
T23.add_edges_from(edgelist23)
k23=nx.graph_edit_distance(T21, T23)
print('Tree T21 and T23 are at GED=',k23)


T24=nx.Graph()
edgelist24=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(8,9),(4,10)]
T24.add_edges_from(edgelist24)
k24=nx.graph_edit_distance(T21, T24)
print('Tree T21 and T24 are at GED=',k24)

T25=nx.Graph()
edgelist25=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(8,9),(5,10)]
T25.add_edges_from(edgelist25)
k25=nx.graph_edit_distance(T21, T25)
print('Tree T21 and T25 are at GED=',k25)

T26=nx.Graph()
edgelist26=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(8,9),(6,10)]
T26.add_edges_from(edgelist26)
k26=nx.graph_edit_distance(T21, T26)
print('Tree T21 and T26 are at GED=',k26)

T27=nx.Graph()
edgelist27=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(8,9),(5,10)]
T27.add_edges_from(edgelist27)
k27=nx.graph_edit_distance(T21, T27)
print('Tree T21 and T27 are at GED=',k27)

T28=nx.Graph()
edgelist28=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(8,9),(4,10)]
T28.add_edges_from(edgelist28)
k28=nx.graph_edit_distance(T21, T28)
print('Tree T21 and T28 are at GED=',k28)

T29=nx.Graph()
edgelist29=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(8,9),(6,10)]
T29.add_edges_from(edgelist29)
k29=nx.graph_edit_distance(T21, T29)
print('Tree T21 and T29 are at GED=',k29)

T30=nx.Graph()
edgelist30=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(2,9),(3,10)]
T30.add_edges_from(edgelist30)
k30=nx.graph_edit_distance(T21, T30)
print('Tree T21 and T30 are at GED=',k30)

T31=nx.Graph()
edgelist31=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(2,9),(4,10)]
T31.add_edges_from(edgelist31)
k31=nx.graph_edit_distance(T21, T31)
print('Tree T21 and T31 are at GED=',k31)

T32=nx.Graph()
edgelist32=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(2,9),(5,10)]
T32.add_edges_from(edgelist32)
k32=nx.graph_edit_distance(T21, T32)
print('Tree T21 and T32 are at GED=',k32)

T33=nx.Graph()
edgelist33=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(2,9),(6,10)]
T33.add_edges_from(edgelist33)
k33=nx.graph_edit_distance(T21, T33)
print('Tree T21 and T33 are at GED=',k33)

T34=nx.Graph()
edgelist34=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(5,8),(5,9),(6,10)]
T34.add_edges_from(edgelist34)
k34=nx.graph_edit_distance(T21, T34)
print('Tree T21 and T34 are at GED=',k34)

T35=nx.Graph()
edgelist35=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(3,9),(4,10)]
T35.add_edges_from(edgelist35)
k35=nx.graph_edit_distance(T21, T35)
print('Tree T21 and T35 are at GED=',k35)

T36=nx.Graph()
edgelist36=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(3,9),(5,10)]
T36.add_edges_from(edgelist36)
k36=nx.graph_edit_distance(T21, T36)
print('Tree T21 and T36 are at GED=',k36)

T37=nx.Graph()
edgelist37=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(5,9),(6,10)]
T37.add_edges_from(edgelist37)
k37=nx.graph_edit_distance(T21, T37)
print('Tree T21 and T37 are at GED=',k37)

T38=nx.Graph()
edgelist38=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(4,9),(6,10)]
T38.add_edges_from(edgelist38)
k38=nx.graph_edit_distance(T21, T38)
print('Tree T21 and T38 are at GED=',k38)

T39=nx.Graph()
edgelist39=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(4,9),(5,10)]
T39.add_edges_from(edgelist39)
k39=nx.graph_edit_distance(T21, T39)
print('Tree T21 and T39 are at GED=',k39)

T40=nx.Graph()
edgelist40=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(4,9),(6,10)]
T40.add_edges_from(edgelist40)
k40=nx.graph_edit_distance(T21, T40)
print('Tree T21 and T40 are at GED=',k40)

T41=nx.Graph()
edgelist41=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(3,9),(6,10)]
T41.add_edges_from(edgelist41)
k41=nx.graph_edit_distance(T21, T41)
print('Tree T21 and T41 are at GED=',k41)

T42=nx.Graph()
edgelist42=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(3,9),(4,10)]
T42.add_edges_from(edgelist42)
k42=nx.graph_edit_distance(T21, T42)
print('Tree T21 and T42 are at GED=',k42)

T43=nx.Graph()
edgelist43=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(3,9),(5,10)]
T43.add_edges_from(edgelist43)
k43=nx.graph_edit_distance(T21, T43)
print('Tree T21 and T43 are at GED=',k43)

T44=nx.Graph()
edgelist44=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(4,9),(5,10)]
T44.add_edges_from(edgelist44)
k44=nx.graph_edit_distance(T21, T44)
print('Tree T21 and T44 are at GED=',k44)

T45=nx.Graph()
edgelist45=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(4,9),(5,10)]
T45.add_edges_from(edgelist45)
k45=nx.graph_edit_distance(T21, T45)
print('Tree T21 and T45 are at GED=',k45)

T46=nx.Graph()
edgelist46=[(1,2),(2,3),(3,4),(4,5),(5,6),(4,7),(7,8),(7,9),(5,10)]
T46.add_edges_from(edgelist46)
k46=nx.graph_edit_distance(T21, T46)
print('Tree T21 and T46 are at GED=',k46)

T47=nx.Graph()
edgelist47=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(7,9),(8,10)]
T47.add_edges_from(edgelist47)
k47=nx.graph_edit_distance(T21, T47)
print('Tree T21 and T47 are at GED=',k47)

T48=nx.Graph()
edgelist48=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(4,8),(7,9),(8,10)]
T48.add_edges_from(edgelist48)
k48=nx.graph_edit_distance(T21, T48)
print('Tree T21 and T48 are at GED=',k48)

T49=nx.Graph()
edgelist49=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(3,9),(9,10)]
T49.add_edges_from(edgelist49)
k49=nx.graph_edit_distance(T21, T49)
print('Tree T21 and T49 are at GED=',k49)

T50=nx.Graph()
edgelist50=[(1,2),(2,3),(3,4),(4,5),(5,6),(4,7),(7,8),(4,9),(5,10)]
T50.add_edges_from(edgelist50)
k50=nx.graph_edit_distance(T21, T50)
print('Tree T21 and T50 are at GED=',k50)

T51=nx.Graph()
edgelist51=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(8,9),(4,10)]
T51.add_edges_from(edgelist51)
k51=nx.graph_edit_distance(T21, T51)
print('Tree T21 and T51 are at GED=',k51)

T52=nx.Graph()
edgelist52=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(4,8),(8,9),(5,10)]
T52.add_edges_from(edgelist52)
k52=nx.graph_edit_distance(T21, T52)
print('Tree T21 and T52 are at GED=',k52)

T53=nx.Graph()
edgelist53=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(7,8),(3,9),(4,10)]
T53.add_edges_from(edgelist53)
k53=nx.graph_edit_distance(T21, T53)
print('Tree T21 and T53 are at GED=',k53)

T54=nx.Graph()
edgelist54=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(4,9),(9,10)]
T54.add_edges_from(edgelist54)
k54=nx.graph_edit_distance(T21, T54)
print('Tree T21 and T54 are at GED=',k54)

T55=nx.Graph()
edgelist55=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(4,9),(9,10)]
T55.add_edges_from(edgelist55)
k55=nx.graph_edit_distance(T21, T55)
print('Tree T21 and T55 are at GED=',k55)

T56=nx.Graph()
edgelist56=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(7,8),(3,9),(5,10)]
T56.add_edges_from(edgelist56)
k56=nx.graph_edit_distance(T21, T56)
print('Tree T21 and T56 are at GED=',k56)

T57=nx.Graph()
edgelist57=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(4,9),(9,10)]
T57.add_edges_from(edgelist57)
k57=nx.graph_edit_distance(T21, T57)
print('Tree T21 and T57 are at GED=',k57)


T58=nx.Graph()
edgelist58=[(1,2),(2,3),(3,4),(4,5),(5,6),(4,7),(4,8),(5,9),(5,10)]
T58.add_edges_from(edgelist58)
k58=nx.graph_edit_distance(T21, T58)
print('Tree T21 and T58 are at GED=',k58)

T59=nx.Graph()
edgelist59=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(3,9),(4,10)]
T59.add_edges_from(edgelist59)
k59=nx.graph_edit_distance(T21, T59)
print('Tree T21 and T59 are at GED=',k59)

T60=nx.Graph()
edgelist60=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(3,9),(5,10)]
T60.add_edges_from(edgelist60)
k60=nx.graph_edit_distance(T21, T60)
print('Tree T21 and T60 are at GED=',k60)


T61=nx.Graph()
edgelist61=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(5,9),(5,10)]
T61.add_edges_from(edgelist61)
k61=nx.graph_edit_distance(T21, T61)
print('Tree T21 and T61 are at GED=',k61)


T62=nx.Graph()
edgelist62=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(4,9),(5,10)]
T62.add_edges_from(edgelist62)
k62=nx.graph_edit_distance(T21, T62)
print('Tree T21 and T62 are at GED=',k62)


T63=nx.Graph()
edgelist63=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(5,9),(5,10)]
T63.add_edges_from(edgelist63)
k63=nx.graph_edit_distance(T21, T63)
print('Tree T21 and T63 are at GED=',k63)



T64=nx.Graph()
edgelist64=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(3,9),(4,10)]
T64.add_edges_from(edgelist64)
k64=nx.graph_edit_distance(T21, T64)
print('Tree T21 and T64 are at GED=',k64)


T65=nx.Graph()
edgelist65=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(4,8),(4,9),(5,10)]
T65.add_edges_from(edgelist65)
k65=nx.graph_edit_distance(T21, T65)
print('Tree T21 and T65 are at GED=',k65)



T66=nx.Graph()
edgelist66=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(4,9),(5,10)]
T66.add_edges_from(edgelist66)
k66=nx.graph_edit_distance(T21, T66)
print('Tree T21 and T66 are at GED=',k66)


T67=nx.Graph()
edgelist67=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(4,9),(5,10)]
T67.add_edges_from(edgelist67)
k67=nx.graph_edit_distance(T21, T67)
print('Tree T21 and T67 are at GED=',k67)


T68=nx.Graph()
edgelist68=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(4,9),(4,10)]
T68.add_edges_from(edgelist68)
k68=nx.graph_edit_distance(T21, T68)
print('Tree T21 and T68 are at GED=',k68)



T69=nx.Graph()
edgelist69=[(1,2),(2,3),(3,4),(4,5),(2,6),(3,7),(7,8),(7,9),(4,10)]
T69.add_edges_from(edgelist69)
k69=nx.graph_edit_distance(T21, T69)
print('Tree T21 and T69 are at GED=',k69)


T70=nx.Graph()
edgelist70=[(1,2),(2,3),(3,4),(4,5),(3,6),(6,7),(3,8),(8,9),(4,10)]
T70.add_edges_from(edgelist70)
k70=nx.graph_edit_distance(T21, T70)
print('Tree T21 and T70 are at GED=',k70)

T71=nx.Graph()
edgelist71=[(1,2),(2,3),(3,4),(4,5),(3,6),(6,7),(3,8),(4,9),(4,10)]
T71.add_edges_from(edgelist71)
k71=nx.graph_edit_distance(T21, T71)
print('Tree T21 and T71 are at GED=',k71)


T72=nx.Graph()
edgelist72=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(3,8),(8,9),(4,10)]
T72.add_edges_from(edgelist72)
k72=nx.graph_edit_distance(T21, T72)
print('Tree T21 and T72 are at GED=',k72)

T73=nx.Graph()
edgelist73=[(1,2),(2,3),(3,4),(4,5),(2,6),(3,7),(7,8),(3,9),(4,10)]
T73.add_edges_from(edgelist73)
k73=nx.graph_edit_distance(T21, T73)
print('Tree T21 and T73 are at GED=',k73)


T74=nx.Graph()
edgelist74=[(1,2),(2,3),(3,4),(4,5),(2,6),(3,7),(3,8),(4,9),(4,10)]
T74.add_edges_from(edgelist74)
k74=nx.graph_edit_distance(T21, T74)
print('Tree T21 and T74 are at GED=',k74)

T75=nx.Graph()
edgelist75=[(1,2),(2,3),(3,4),(4,5),(2,6),(2,7),(3,8),(4,9),(4,10)]
T75.add_edges_from(edgelist75)
k75=nx.graph_edit_distance(T21, T75)
print('Tree T21 and T75 are at GED=',k75)



T104=nx.Graph()
edgelist104=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(2,8),(2,9),(2,10)]
T104.add_edges_from(edgelist104)
k104=nx.graph_edit_distance(T21, T104)
print('Tree T21 and T104 are at GED=',k104)


T105=nx.Graph()
edgelist105=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(3,8),(3,9),(3,10)]
T105.add_edges_from(edgelist105)
k105=nx.graph_edit_distance(T21, T105)
print('Tree T21 and T105 are at GED=',k105)


T106=nx.Graph()
edgelist106=[(1,2),(2,3),(3,4),(4,5),(5,6),(6,7),(4,8),(4,9),(4,10)]
T106.add_edges_from(edgelist106)
k106=nx.graph_edit_distance(T21, T106)
print('Tree T21 and T106 are at GED=',k106)





T95=nx.Graph()
edgelist95=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(2,10)]
T95.add_edges_from(edgelist95)
k95=nx.graph_edit_distance(T21, T95)
print('Tree T21 and T95 are at GED=',k95)


T96=nx.Graph()
edgelist96=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(3,10)]
T96.add_edges_from(edgelist96)
k96=nx.graph_edit_distance(T21, T96)
print('Tree T21 and T96 are at GED=',k96)


T97=nx.Graph()
edgelist97=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(3,10)]
T97.add_edges_from(edgelist97)
k97=nx.graph_edit_distance(T21, T97)
print('Tree T21 and T97 are at GED=',k97)


T98=nx.Graph()
edgelist98=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(4,10)]
T98.add_edges_from(edgelist98)
k98=nx.graph_edit_distance(T21, T98)
print('Tree T21 and T98 are at GED=',k98)


T99=nx.Graph()
edgelist99=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(2,8),(2,9),(5,10)]
T99.add_edges_from(edgelist99)
k99=nx.graph_edit_distance(T21, T99)
print('Tree T21 and T99 are at GED=',k99)

T100=nx.Graph()
edgelist100=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(4,10)]
T100.add_edges_from(edgelist100)
k100=nx.graph_edit_distance(T21, T100)
print('Tree T21 and T100 are at GED=',k100)


T101=nx.Graph()
edgelist101=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(5,10)]
T101.add_edges_from(edgelist101)
k101=nx.graph_edit_distance(T21, T101)
print('Tree T21 and T101 are at GED=',k101)


T102=nx.Graph()
edgelist102=[(1,2),(2,3),(3,4),(4,5),(5,6),(2,7),(3,8),(3,9),(3,10)]
T102.add_edges_from(edgelist102)
k102=nx.graph_edit_distance(T21, T102)
print('Tree T21 and T102 are at GED=',k102)


T103=nx.Graph()
edgelist103=[(1,2),(2,3),(3,4),(4,5),(5,6),(3,7),(3,8),(3,9),(9,10)]
T103.add_edges_from(edgelist103)
k103=nx.graph_edit_distance(T21, T103)
print('Tree T21 and T103 are at GED=',k103)

