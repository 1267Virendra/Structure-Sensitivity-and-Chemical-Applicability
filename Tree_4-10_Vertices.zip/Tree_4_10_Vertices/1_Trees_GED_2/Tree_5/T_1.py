# -*- coding: utf-8 -*-
"""
Created on Fri Aug 26 14:54:55 2022

@author: User
"""

import networkx as nx 


T1=networkx.Graph()
edgelist1=[(1,2),(2,3),(3,4),(4,5)]
T1.add_edges_from(edgelist1)
k1=networkx.graph_edit_distance(T1, T1)
print('Tree T1 and T2 are at GED=',k1)


T2=nx.Graph()
edgelist2=[(1,2),(2,3),(3,4),(2,5)]
T2.add_edges_from(edgelist2)

k2=nx.graph_edit_distance(T1, T2)
print('Tree T1 and T2 are at GED=',k2)


T3=nx.Graph()
edgelist3=[(1,2),(2,3),(2,4),(2,5)]
T3.add_edges_from(edgelist3)

k3=nx.graph_edit_distance(T1, T3)
print('Tree T1 and T3 are at GED=',k3)

k4=nx.graph_edit_distance(T2, T3)
print('Tree T2 and T3 are at GED=',k4)
