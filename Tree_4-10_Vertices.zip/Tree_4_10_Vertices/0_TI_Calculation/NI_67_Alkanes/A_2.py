# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import networkx as nx 
import numpy as np
import array as arr
import math

T1=nx.Graph()
edgelist1=[(1,4),(2,4),(3,4)]

T1.add_edges_from(edgelist1)

N=0
IN1=0
IN2=0
M1=0
M2=0
F=0
R=0
RR=0
SDD=0
ISI=0
SO=0
HM1=0
HM2=0
GQ=0
QG=0

for (i,j) in edgelist1:
    
    a=T1.degree[i]
    b=T1.degree[j]
    N=math.sqrt(a+b)+N
    IN1=math.sqrt((a+b)/(a*b))+IN1
    IN2=math.sqrt((a*b)/(a+b))+IN2
    M1=a+b+M1
    M2=a*b+M2
    F=math.pow(a,2)+math.pow(b,2)+F
    R=1/(math.sqrt(a*b))+R
    RR=math.sqrt(a*b)+RR
    SDD=(a/b)+(b/a)+SDD
    ISI=(a*b)/(a+b)+ISI
    SO=math.sqrt(math.pow(a,2)+math.pow(b,2))+SO
    HM1=math.pow((a+b),2)+HM1
    HM2=math.pow((a*b),2)+HM2
    GQ=math.sqrt((2*a*b)/(math.pow(a,2)+math.pow(b,2)))+GQ
    QG=math.sqrt((math.pow(a,2)+math.pow(b,2))/(2*a*b))+QG

print('Topological indices\n',N,IN1,IN2,M1,M2,F,R,RR,SDD,ISI,SO,HM1,HM2,GQ,QG)
print('Nirmala index=',N)
print('first Nirmala index=',IN1)
print('second Nirmala index=',IN2)    
print('first Zagreb index=',M1)
print('second Zagreb index=',M2)
print('forgotten index=',F)
print('Randic index=',R)
print('reciprocal Randic index=',RR)
print('SDD index=',SDD)
print('inverse sum index=',ISI)
print('Sombor index=',SO)
print('HM1 index=',HM1)
print('HM2 index=',HM2)
print('GQ index=',GQ)
print('QG index=',QG)


    
   
