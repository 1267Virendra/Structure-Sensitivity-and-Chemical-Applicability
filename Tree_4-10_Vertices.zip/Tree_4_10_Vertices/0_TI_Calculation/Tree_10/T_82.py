# -*- coding: utf-8 -*-
"""
Created on Mon Sep 19 00:28:23 2022

@author: User
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Sep 18 00:21:27 2022

@author: User
"""


import networkx as nx 
import numpy as np
import matplotlib.pyplot as plt
import array as arr
import math

T1=nx.Graph()
edgelist1=[(1,2),(2,3),(3,4),(4,5),(3,6),(3,7),(3,8),(3,9),(3,10)]
T1.add_edges_from(edgelist1)

nx.draw(T1,with_labels=1)


M1=0
M2=0
mM2=0
F=0
R=0
RR=0
H=0
SDD=0
ISI=0
AZ=0
ABC=0
HM1=0
HM2=0
GA=0
AG=0
SO=0
mSO=0
N=0
IN1=0
IN2=0
GQ=0
QG=0
SCI=0
ReZ3=0
for (i,j) in edgelist1:
    
    a=T1.degree[i]
    b=T1.degree[j]
    M1=a+b+M1
    M2=a*b+M2
    mM2=1/(a*b)+mM2
    F=math.pow(a,2)+math.pow(b,2)+F
    R=1/(math.sqrt(a*b))+R
    RR=math.sqrt(a*b)+RR
    H=2/(a+b) +H
    SDD=(a/b)+(b/a)+SDD
    ISI=(a*b)/(a+b)+ISI
    AZ=math.pow((a*b)/(a+b-2),3)+AZ
    ABC=math.sqrt((a+b-2)/(a*b))+ABC
    HM1=math.pow((a+b),2)+HM1
    HM2=math.pow((a*b),2)+HM2
    GA=(2*math.sqrt(a*b))/(a+b)+GA
    AG=(a+b)/(2*math.sqrt(a*b))+AG
    mSO=1/(math.sqrt(math.pow(a,2)+math.pow(b,2)))+mSO
    SO=math.sqrt(math.pow(a,2)+math.pow(b,2))+SO
    N=math.sqrt(a+b)+N
    IN1=math.sqrt((a+b)/(a*b))+IN1
    IN2=math.sqrt((a*b)/(a+b))+IN2
    GQ=math.sqrt((2*a*b)/(math.pow(a,2)+math.pow(b,2)))+GQ
    QG=math.sqrt((math.pow(a,2)+math.pow(b,2))/(2*a*b))+QG
    SCI=1/(math.sqrt(a+b))+SCI
    ReZ3=a*b*(a+b)+ReZ3
    
   
print(M1,M2,mM2,F,R,RR,SDD,H,ISI,AZ,ABC,HM1,HM2,GA,AG,SO,mSO,N,IN1,IN2,GQ,QG,SCI)
print('first Zagreb index=',M1,M2)
print('second Zagreb index=',M2)
print('modefied second Zagreb index=',mM2)
print('forgotten index=',F)
print('Randic index=',R)
print('reciprocal Randic index=',RR)
print('harmonic index=',H)
print('SDD index=',SDD)
print('inverse sum index=',ISI)
print('agumented Zagreb index=',AZ)
print('ABC index=',ABC)
print('HM1 index=',HM1)
print('HM2 index=',HM2)
print('GA index=',GA)
print('AG index=',AG)
print('mSO index=',mSO)
print('Sombor index=',SO)
print('Nirmala index=',N)
print('first Nirmala index=',IN1)
print('second Nirmala index=',IN2)
print('GQ index=',GQ)
print('QG index=',QG)
print('Sum connectivity index index=',SCI)
print('Redefine Zagreb index =',ReZ3)
    
    
   